from django.db import models
 
# Create your models here. 
from django.db import models
from datetime import datetime
# Create your models here.
x=[
    ('Young Adult','Young Adult'),
    ('Memoir','Memoir'),
    ('Thriller','Thriller'),
    ('Mystery','Mystery'),
    ('Romance','Romance'),
    ('Fiction','Fiction'),
    ('Fantasy','Fantasy'),
    ('Crime','Crime'),
    ('Dystopian','Dystopian'),
]
class Books(models.Model): 
    title= models.CharField(max_length=400)
    author=models.CharField(max_length=400)
    category=models.CharField(max_length=400, choices=x)
    image = models.ImageField(upload_to='photos/%y/%m/%d',  default='photos/25/5/25/Favicon.png')
    stock= models.IntegerField()
    borrowedCount= models.IntegerField(verbose_name='Borrowed Count')
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.title
    
    class Meta:
        verbose_name ='Book'
        #ordering =['-title'] 
        


