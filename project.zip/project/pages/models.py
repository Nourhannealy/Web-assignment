from django.db import models
 
# Create your models here. 
from django.db import models
from datetime import datetime
# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name
    class Meta:
        verbose_name ='Categorie'
    
class Books(models.Model): 
    title= models.CharField(max_length=400)
    author=models.CharField(max_length=400)
    categories = models.ManyToManyField(Category, related_name='books') # many to many relationship so admin can choose mutiple categories
    image = models.ImageField(upload_to='photos/%y/%m/%d', default='photos/25/5/25/Favicon.png')
    stock= models.IntegerField()
    borrowedCount= models.IntegerField(verbose_name='Borrowed Count')
    description = models.TextField(null=True, blank=True)
    chapters = models.IntegerField(null=True, blank=True)
    pages = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return self.title
     
    class Meta:
        verbose_name ='Book'
        #ordering =['-title'] 
        


