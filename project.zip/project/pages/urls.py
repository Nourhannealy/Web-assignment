from django.urls import path
from . import views

urlpatterns = [

    path('add_book/', views.admin_add_book, name='add_book'), 
    path('admin_book_details/<int:book_id>/', views.admin_book_details, name='admin_book_details'), # dynamic 
    path('edit_book/', views.admin_edit_book, name='edit_book'), # make dynamic
    path('admin_profile/', views.admin_profile, name='admin_profile'),
    path('admin_settings/', views.admin_settings, name='admin_settings'),
    path('admin_land_book/', views.admin_landing_books, name='admin_land_books'),
    path('login/', views.login, name='login'),
    path('', views.page1_start, name='start'),

    path('book_details/<int:book_id>/', views.reader_book_details, name='reader_book_details'), #dynamic 
    path('return/', views.reader_return_book, name='reader_book_return'),
    path('book_status/', views.reader_book_status, name='reader_book_status'),
    path('completed/', views.reader_completed_or_not, name='completed_or_not'),
    path('land_book/', views.reader_landing_book, name='reader_land_book'),
    path('profile/', views.reader_profile, name='reader_profile'),
    path('settings/', views.reader_settings, name='reader_settings'),
    path('sign-up/', views.sign_up, name='sign-up'),


    # for when a book is deleted
    path('delete_book/<int:book_id>/', views.delete_book, name='delete_book'),
    # for when a book is borrowed
        path('books/<int:book_id>/borrow/',
         views.borrow_book,
         name='borrow_book'),

]
 