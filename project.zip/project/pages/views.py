from django.shortcuts import render, get_object_or_404
from .models import Books
from django.shortcuts import redirect
from django.views.decorators.http import require_POST
from django.http import JsonResponse

# Create your views here.

def admin_add_book(request):
    return render(request, 'pages/Admin_Add_Book.html')

def admin_book_details(request, book_id):
    # Get the book details by ID
    book = get_object_or_404(Books, id=book_id)
    return render(request, 'pages/Admin_Book_Details.html', {'book': book})

def admin_edit_book(request):
    return render(request, 'pages/Admin_Edit_Book.html')

def admin_page(request):
    return render(request, 'pages/Admin_Page.html') 

def admin_profile(request):
    return render(request, 'pages/Admin_Profile.html')

def admin_settings(request):
    return render(request, 'pages/Admin_Settings.html')

def admin_landing_books(request):
    x= {'books':Books.objects.all()}
    return render(request, 'pages/Admin_Landing_books.html',x)

def login(request):
    return render(request, 'pages/Login.html')

def page1_start(request):
    return render(request, 'pages/Page1_Start.html')

def reader_book_details(request, book_id):
    # Get the book details by ID
    book = get_object_or_404(Books, id=book_id)
    return render(request, 'pages/Reader_Book_Details.html', {'book': book})

def reader_return_book(request):
    return render(request, 'pages/Reader_Book_Return.html')

def reader_book_status(request):
    return render(request, 'pages/Reader_Book_Status.html')

def reader_completed_or_not(request):
    return render(request, 'pages/Reader_Completed_or_not.html')

def reader_landing_book(request):
    x= {'books':Books.objects.all()}
    return render(request, 'pages/Reader_Landing_Book.html',x)

def reader_page(request):
    return render(request, 'pages/Reader_Page.html')

def reader_profile(request):
    return render(request, 'pages/Reader_Profile.html')

def reader_settings(request):
    return render(request, 'pages/Reader_Settings.html')

def sign_up(request):
    return render(request, 'pages/Sign-up.html')


# for when a book is deleted
def delete_book(request, book_id):
    book = get_object_or_404(Books, id=book_id)
    book.delete()
    # Redirect to a page after deletion (e.g., the landing page)
    return redirect('admin_land_books')

# for when a book is borrowed
@require_POST
def borrow_book(request, book_id):
    book = get_object_or_404(Books, id=book_id)
    if book.stock > 0:
        book.stock -= 1
        book.borrowedCount += 1
        book.save()
        return JsonResponse({'success': True, 'new_stock': book.stock})
    else:
        return JsonResponse({'success': False, 'error': 'Out of stock'}, status=400)