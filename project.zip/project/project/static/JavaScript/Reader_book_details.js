// Reader_book_details.js

// helper to pull the CSRF token from meta tag
function getCSRFToken() {
  const tokenMeta = document.querySelector('meta[name="csrf-token"]');
  return tokenMeta ? tokenMeta.getAttribute('content') : '';
}

// generic custom alert UI builder
function showCustomAlert(message, onConfirm = null, onCancel = null, singleButton = false) {
  const alertMessage = document.getElementById('alertMessage');
  const customAlert  = document.getElementById('customAlert');
  let confirmBtn     = document.getElementById('alertConfirmBtn');
  let cancelBtn      = document.getElementById('alertCancelBtn');

  // set alert text
  alertMessage.textContent = message;
  // show the overlay
  customAlert.style.display = 'flex';

  // clear old event listeners by replacing buttons
  const newConfirmBtn = confirmBtn.cloneNode(true);
  const newCancelBtn  = cancelBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
  cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);

  // hide cancel if single-button alert
  newCancelBtn.style.display = singleButton ? 'none' : 'inline-block';

  // wire up confirm click
  newConfirmBtn.addEventListener('click', () => {
    customAlert.style.display = 'none';
    if (onConfirm) onConfirm();
  });

  // wire up cancel click
  newCancelBtn.addEventListener('click', () => {
    customAlert.style.display = 'none';
    if (onCancel) onCancel();
  });
}

// show borrowing alert if stock exists, or out-of-stock notice
function showBorrowAlert(bookId, stock) {
  if (stock > 0) {
    showCustomAlert(
      "Are you sure you want to borrow this book?",
      () => confirmBorrow(bookId)
    );
  } else {
    showCustomAlert(
      "This book is out of stock.",
      null,
      null,
      true
    );
  }
}

// send POST to decrement stock silently
function confirmBorrow(bookId) {
  fetch(`/books/${bookId}/borrow/`, {
    method: 'POST',
    credentials: 'same-origin',            // ← include session cookie
    headers: {
      'X-CSRFToken': getCSRFToken(),
      'Accept':      'application/json'
    }
  })
  .then(res => {
    if (!res.ok) {
      console.error('Server returned HTTP', res.status);
    }
  })
  .catch(err => console.error('Borrow failed:', err))
  .finally(() => {
    const customAlert = document.getElementById('customAlert');
    if (customAlert) customAlert.style.display = 'none';
  });
}


// export functions to global scope if using modules
window.showBorrowAlert = showBorrowAlert;
window.confirmBorrow    = confirmBorrow;